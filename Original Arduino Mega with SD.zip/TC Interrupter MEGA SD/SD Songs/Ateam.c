// Playtune bytestream for file "C:\Users\Atomfusion\Desktop\Tesla Coil Songs to be checked/Ateam.mid" created by MIDITONES V1.14 on Sat Jul 22 11:10:39 2017
// command line: miditones -t2 C:\Users\Atomfusion\Desktop\Tesla Coil Songs to be checked/Ateam 
const unsigned char PROGMEM score [] = {
// The A Team
0x90,63, 1,104, 0x90,63, 0,120, 0x90,58, 0,240, 0x90,63, 3,192, 0x90,56, 0,240, 0x90,58, 1,224, 0x90,51, 
3,192, 0x90,58, 0,240, 0x90,63, 0,240, 0x90,58, 0,240, 0x90,65, 0,240, 0x90,63, 3,192, 0x90,61, 1,104, 
0x90,60, 0,120, 0x90,58, 0,120, 0x90,56, 1,104, 0x90,58, 3,192, 0x90,63, 1,104, 0x90,63, 0,120, 0x90,58, 
0,240, 0x90,63, 3,192, 0x90,55, 0,240, 0x90,56, 1,224, 0x90,58, 0,240, 0x90,51, 3,192, 0x90,56, 0,240, 
0x90,55, 1,224, 0x90,51, 0,240, 0x90,56, 1,224, 0x90,55, 1,224, 0x90,56, 1,224, 0x90,55, 1,224, 0x90,51, 
0,240, 0x90,53, 2,208, 0x90,51, 3,192, 0x80, 0xf0};
// This score contains 142 bytes, and 1 tone generator is used.
