// Playtune bytestream for file "C:\Users\Atomfusion\Desktop\Tesla Coil Songs to be checked/starwars.mid" created by MIDITONES V1.14 on Sat Jul 22 12:03:48 2017
// command line: miditones -t2 C:\Users\Atomfusion\Desktop\Tesla Coil Songs to be checked/starwars 
const unsigned char PROGMEM score [] = {
// Star Wars Theme
0x90,53, 0,166, 0x90,53, 0,166, 0x90,53, 0,166, 0x90,58, 3,231, 0x90,65, 3,231, 0x90,63, 0,166, 0x90,62, 
0,166, 0x90,60, 0,166, 0x90,70, 3,231, 0x90,65, 1,243, 0x90,63, 0,166, 0x90,62, 0,166, 0x90,60, 0,166, 
0x90,70, 3,231, 0x90,65, 1,243, 0x90,63, 0,166, 0x90,62, 0,166, 0x90,63, 0,166, 0x90,60, 2,154, 0x80, 1,77, 
0x90,53, 0,166, 0x90,53, 0,166, 0x90,53, 0,166, 0x90,58, 3,231, 0x90,65, 3,231, 0x90,63, 0,166, 0x90,62, 
0,166, 0x90,60, 0,166, 0x90,70, 3,231, 0x90,65, 1,243, 0x90,63, 0,166, 0x90,62, 0,166, 0x90,60, 0,166, 
0x90,70, 3,231, 0x90,65, 1,243, 0x90,63, 0,166, 0x90,62, 0,166, 0x90,63, 0,166, 0x90,60, 2,154, 0x80, 0xf0};
// This score contains 157 bytes, and 1 tone generator is used.
